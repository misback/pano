package com.uni.pano.event;

/**
 * Created by DELL on 2017/3/10.
 */

public class LanguageChangeEvent {
}

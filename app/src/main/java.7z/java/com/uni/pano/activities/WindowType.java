package com.uni.pano.activities;

/**
 * @描述：     @窗口类型
 * @作者：     @蒋诗朋
 * @创建时间： @2017-04-25
 */
public enum WindowType {
    CLEAR,SHARE,UPDATE,DELETE,PROGRESS,CANCEL
}

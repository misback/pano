package com.uni.pano.logutils;

/**
 * Created by 陈希然 on 2016/7/25.
 */
public class Constants {

    //    public static final String ACTION_EXIT = "com.perfant.fury.action.ACTION_EXIT";
    public static final String ACTION_PANORAMIC_CAMERA = "com.perfant.fury.action.ACTION_PANORAMIC_CAMERA";

    public static final String PREFERENCE_KEY_LANGUAGE = "key_language";
    public static final int PREFERENCE_KEY_LANGUAGE_VALUE_CHINESE = 1;
    public static final int PREFERENCE_KEY_LANGUAGE_VALUE_ENGLISH = 2;
    public static final int PREFERENCE_KEY_LANGUAGE_VALUE_FOLLOW_SYSTEM = 3;
}

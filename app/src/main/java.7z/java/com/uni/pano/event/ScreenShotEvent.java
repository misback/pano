package com.uni.pano.event;

/**
 * Created by DELL on 2017/3/23.
 */

public class ScreenShotEvent {
    public String fileName;
    public ScreenShotEvent(String name){
        fileName = name;
    }
}

package com.uni.pano.event;

/**
 * Created by DELL on 2017/3/2.
 */

public class DeInitGLEvent {
}

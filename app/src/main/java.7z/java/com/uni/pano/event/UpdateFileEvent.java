package com.uni.pano.event;

/**
 * Created by DELL on 2017/3/23.
 */

public class UpdateFileEvent {
    public String fileName;
    public UpdateFileEvent(String name){
        fileName = name;
    }
}
